﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebAplication1.domainEntityFramework.IRepositories;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebAplication1.domainEntityFramework.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T: class

    {
        private readonly HotelDbContext _context;

        public BaseRepository(HotelDbContext context)
        {
            _context = context;
        }

        public async Task CreateAsync(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
        }
       
        public List<T> GetAll()
        {
            return _context.Set<T>().ToList();
            //toList intoarce lista
        }

        public async Task<T> GetByCondition(Expression<Func<T, bool>> expression)
        {
            return await _context.Set<T>().FirstOrDefaultAsync(expression);
        }

        public T Update(T entity)  //nu are async,nici delete
        {
            return _context.Set<T>().Add(entity).Entity;
        }

        public void Delete(T entity) // modificat
        {
            _context.Set<T>().Remove(entity);
        }
    }
}
