﻿using LabDAW.Models;
using System;
using System.Collections.Generic;
using System.Text;
using WebAplication1.domainEntityFramework.IRepositories;

namespace WebAplication1.domainEntityFramework.Repositories
{
    public class RoomRepository : BaseRepository<Room>, IRoomRepository
    {
        public RoomRepository(HotelDbContext context) : base(context) 
        {
        }
    }
}
