﻿using System;

namespace WebAplication1.domainEntityFramework
{
    public class Class1
    {

    }
}
