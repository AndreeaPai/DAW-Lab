﻿using System;
using System.Collections.Generic;
using System.Text;
using LabDAW.Models; // pt db set
using Microsoft.EntityFrameworkCore;


namespace WebAplication1.domainEntityFramework
{
    public class HotelDbContext : DbContext // DbContext class
    {
        public DbSet<Room> Room {get; set;}
        public DbSet<Employee> Employee {get; set;}
        public DbSet<Customer> Customer {get; set;}
        public DbSet<Booking> Booking {get; set;}

        //constructor 
        public HotelDbContext(DbContextOptions options) : base(options)
        { 
        }
        
        //string de la baza de date, properties
         protected override void OnConfiguring(DbContextOptionsBuilder options)
            // am pus \\ in loc de \
            => options.UseSqlServer(connectionString: "Data Source = (LocalDB)\\MSSQLLocalDB; " +
                "AttachDbFilename=C:\\Users\\poclitar\\Documents\\MyDataBase.mdf;" +
                "Integrated Security = True; Connect Timeout = 30");

    }
}
