﻿using LabDAW.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace WebAplication1.domainEntityFramework.IRepositories
{
    public interface IRoomRepository : IBaseRepository<Room>
    {
    }
}
