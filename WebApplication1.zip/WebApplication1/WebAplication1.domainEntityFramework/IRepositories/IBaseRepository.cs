﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace WebAplication1.domainEntityFramework.IRepositories
{
    public interface IBaseRepository<T> where T: class
    {
        List<T> GetAll();
        Task<T> GetByCondition(Expression<Func<T, bool>> expression);
        Task CreateAsync(T entity);
        T Update(T entity);
        void Delete(T entity);

    }
}
