﻿using LabDAW.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyApi.Services.Interfeces
{
    public interface IEmployeeServices
    {
        List<Employee> GetAllEmployees();
        Employee GetEmployee(int id);
        Employee CreateEmployee(Employee request);
        Employee UpdateEmployee(int id, Employee request);
        Employee DeleteEmployee(int id);
    }
}
