﻿using LabDAW.Models;
using MyApi.Services.Interfeces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyApi.Services.Implementations
{
    public class EmployeeServices : IEmployeeServices
    {
        private List<Employee> employeeRepository = new List<Employee> {
       
           new Employee
        {
            Id = 1,
            FirstName ="EL1",
            LastName = "El1"

        },

        new Employee{},
        };

        public Employee CreateEmployee(Employee request)
        {
            throw new NotImplementedException();
        }

        public Employee DeleteEmployee(int id)
        {
            throw new NotImplementedException();
        }

        public List<Employee> GetAllEmployees()
        {
            return employeeRepository;
        }

        public Employee GetEmployee(int id)
        {
            Employee employee = employeeRepository.FirstOrDefault(employee => employee.Id == id);
            return employee;
        }

        public Employee UpdateEmployee(int id, Employee request)
        {
            employeeRepository.
        }
    }
}
