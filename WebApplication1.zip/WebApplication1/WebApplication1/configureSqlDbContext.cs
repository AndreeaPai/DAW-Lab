﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAplication1.domainEntityFramework;

namespace WebApplication1
{
    public static class ServicesExtensionMethods
    {
        public static void ConfigureSqlDbContext(this IServiceCollection serv, IConfiguration config)
    {
        string connectionString = config["DatabaseConnections: sqlConnectionString"];// config ?
        serv.AddDbContext<HotelDbContext>(server => server.UseSqlServer(connectionString));
    }
}
}