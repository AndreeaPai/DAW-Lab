﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LabDAW.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyApi.Services.Interfeces;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeServices _employeeServices; // tot ce private incepe cu _
        
        //constructor 
        public EmployeeController(IEmployeeServices employeeServices)
        {
            _employeeServices = employeeServices;

        }

        // adaugat ; imi intoarce employee dupa ce introduc id
        [HttpGet("GetAllEmployees")]
        public IActionResult GetEmployee()
        {
            List<Employee> result = _employeeServices.GetAllEmployees();

            return Ok(result);

        }

        //intoarce not found daca am introdus un id inexistent 
        [HttpGet("GetEmployee/{id}")] //GetEmployee?id=4 - pt FromQuery ? 
        public IActionResult GetEmployeeById([FromRoute] int id)
        {
            Employee result = _employeeServices.GetEmployee(id);
            if (result is null) 
            {
                return new NotFoundObjectResult("Employee not found!!");
            }

            return Ok(result);
        }
    }
}