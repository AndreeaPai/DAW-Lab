﻿namespace LabDAW.Models
{
    public class BasePerson : BaseEntity
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Phone { get; set; }
	}
}
