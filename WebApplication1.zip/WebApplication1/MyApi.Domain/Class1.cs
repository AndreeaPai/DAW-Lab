﻿using System;

namespace MyApi.Domain
{
    public class Class1
    {
    }
}
