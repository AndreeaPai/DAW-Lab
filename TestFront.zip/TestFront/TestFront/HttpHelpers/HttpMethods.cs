﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using System.Security.Policy;
using System.Text.Json.Serialization;
using Newtonsoft.Json;


namespace TestFront.HttpHelpers
{
    public class HttpMethods : IHttpMethods
    {
        private HttpClient _client; //
        public HttpMethods(IHttpClientFactory client) 
        {
            _client = client.CreateClient();
            _client.BaseAddress = new Uri("https://localhost:44386/api");
        }

        public Task<Employee> GetEmployeeAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<Employee> GetRoomAsync() 
        {
            HttpResponseMessage responseMessage = await _client.GetAsync("/employee/GetEmployee/1");

            string htttpContent = await responseMessage.Content.ReadAsStringAsync(); //mi-l interpetreaza sub forma de json
                                                                                     // serializare si deserializare

            Employee myObject = JsonConvert.DeserializeObject<Employee> //
                (htttpContent);

            return myObject;
        
        }

    }
}
