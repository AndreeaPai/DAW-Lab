﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestFront.HttpHelpers
{// pt depency injection

    public interface IHttpMethods // iei metodele din HttpMethods fara async 
    {
        Task<Employee> GetRoomAsync(); 
        Task<Employee> GetEmployeeAsync();
    }
}
