﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TestFront.HttpHelpers;
using TestFront.Models;

namespace TestFront.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpMethods _apiMethods;

        public HomeController(HttpClient client)
        {
           _apiMethods = new HttpMethods(client);
        }

        public async Task<IActionResult> GetEmployeesView() 
        {
            Employee employees = await _apiMethods.GetEmployeeAsync();

            return View("", employees);
        }
        
    }
}
